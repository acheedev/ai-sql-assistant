CREATE OR REPLACE PROCEDURE p$admin_drop_table (
    p_table_name VARCHAR2
) AS
    l_table_name VARCHAR2(30);
BEGIN
    SELECT table_name
      INTO l_table_name
      FROM user_tables
     WHERE table_name = upper(trim(p_table_name));

    dbms_output.put_line('Deleting Table: ' || l_table_name);
    EXECUTE IMMEDIATE 'DROP TABLE '
                      || dbms_assert.sql_object_name(l_table_name)
                      || ' CASCADE CONSTRAINTS';
EXCEPTION
    WHEN no_data_found THEN
        NULL;
END;
